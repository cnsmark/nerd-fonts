
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 36ae3260a107e06f4a5cb76f0a9347010d1e545d
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Aug 3 12:22:36 2025 +0200
        
            Add details to icon sources
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
